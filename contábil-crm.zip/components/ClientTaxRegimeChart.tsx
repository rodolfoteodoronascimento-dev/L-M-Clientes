import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LabelList, Cell } from 'recharts';
import { Client, TaxRegime } from '../types';
import { useTheme } from '../contexts/ThemeContext';

interface ClientTaxRegimeChartProps {
    clients: Client[];
}

const COLORS = ['#22c55e', '#3b82f6', '#8b5cf6', '#f97316']; // Green, Blue, Violet, Orange

export const ClientTaxRegimeChart: React.FC<ClientTaxRegimeChartProps> = ({ clients }) => {
    const data = useMemo(() => {
        const regimeCounts = clients.reduce((acc, client) => {
            if (client.taxRegime) {
                acc[client.taxRegime] = (acc[client.taxRegime] || 0) + 1;
            }
            return acc;
        }, {} as Record<TaxRegime, number>);

        return Object.entries(regimeCounts).map(([name, Clientes]) => ({ name, Clientes }));
    }, [clients]);

    const { theme } = useTheme();
    const isDark = theme === 'dark';

    return (
         <div className="h-full w-full flex flex-col">
            <h3 className="text-lg font-semibold text-black dark:text-white mb-4">Clientes por regime tributário</h3>
            <div className="flex-grow">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                        data={data}
                        margin={{
                            top: 20,
                            right: 20,
                            left: -20,
                            bottom: 5,
                        }}
                        layout="vertical"
                    >
                        <XAxis type="number" hide />
                        <YAxis 
                            type="category" 
                            dataKey="name" 
                            stroke={isDark ? "#a1a1aa" : "#4b5563"}
                            fontSize={12} 
                            tickLine={false} 
                            axisLine={false} 
                            width={100}
                        />
                        <Tooltip
                            cursor={{ fill: isDark ? 'rgba(55, 65, 81, 0.5)' : 'rgba(228, 228, 231, 0.5)' }}
                             contentStyle={{
                                backgroundColor: isDark ? 'rgba(24, 24, 27, 0.9)' : 'rgba(255, 255, 255, 0.9)',
                                borderColor: isDark ? '#3f3f46' : '#e5e7eb',
                                color: isDark ? '#f4f4f5' : '#18181b',
                                backdropFilter: 'blur(4px)',
                                borderRadius: '0.5rem',
                            }}
                        />
                        <Bar dataKey="Clientes" barSize={20} radius={[0, 4, 4, 0]}>
                            {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                            <LabelList dataKey="Clientes" position="right" style={{ fill: isDark ? '#f4f4f5' : '#1f2937', fontSize: '12px', fontWeight: 'bold' }} />
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};